from animal import *

class Ular(Animal):
    def __init__(self, nama, makanan, hidup, berkembangBiak, corak, bissa):
        super().__init__(nama, makanan, hidup, berkembangBiak)
        self.corak = corak
        self.bissa = bissa
    def cetak_ular(self):
        super().cetak()
        print("corak \t\t: ", self.corak,
              "\nbissa \t\t: ", self.bissa)
        
piton = Ular("Piton", "Tikus", "Darat", "Bertelur", "Garis-garis", "Berbissa")
anaconda = Ular("Anaconda", "Ayam", "Darat", "Bertelur", "Bulat-Bulat", "Tidak Berbissa")
anaconda.cetak_ular()
print("=================================================")
piton.cetak_ular()