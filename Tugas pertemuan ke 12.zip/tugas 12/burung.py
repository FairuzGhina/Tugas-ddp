from animal import *

class Burung(Animal):
    def __init__(self, nama, makanan, hidup, berkembangBiak, suara, warna):
        super().__init__(nama, makanan, hidup, berkembangBiak)
        self.suara = suara
        self.warna = warna
    def cetak_burung(self):
        super().cetak()
        print("suara \t\t: ", self.suara,
              "\nwarna \t\t: ", self.warna)
        
merak = Burung("Burung Merak", "Biji-bijian", "Udara", "Bertelur", "Berkicau", "Biru Gradasi")
merpati = Burung("Burung Merpati", "Biji-bijian", "Udara", "Bertelur", "Berkicau", "Putih")
merpati.cetak_burung()
print("=================================================")
merak.cetak_burung()