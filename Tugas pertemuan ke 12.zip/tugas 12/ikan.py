from animal import *

class Ikan(Animal):
    def __init__(self, nama, makanan, hidup, berkembangBiak, ukuran, warna):
        super().__init__(nama, makanan, hidup, berkembangBiak)
        self.ukuran = ukuran
        self.warna = warna
    def cetak_ikan(self):
        super().cetak()
        print("ukuran \t\t: ", self.ukuran,
              "\nwarna \t\t: ", self.warna)
        
koi = Ikan("Ikan Koi", "Pelet", "Air", "Bertelur", "Kecil", "Orange")
lele = Ikan("Ikan Lele", "Pelet", "Air", "Bertelur", "Sedang", "Hitam")
lele.cetak_ikan()
print("=================================================")
koi.cetak_ikan()