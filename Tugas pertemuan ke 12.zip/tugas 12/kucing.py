from animal import *

class Kucing(Animal):
    def __init__(self, nama, makanan, hidup, berkembangBiak, jenis, usia):
        super().__init__(nama, makanan, hidup, berkembangBiak)
        self.jenis = jenis
        self.usia = usia
    def cetak_Kucing(self):
        super().cetak()
        print("jenis \t\t: ", self.jenis,
              "\nusia \t\t: ", self.usia)
        
bubbu = Kucing("Kucing", "Wishkas", "Darat", "Melahirkan", "Anggora", "3 Bulan")
cemong = Kucing("Kucing", "Ikan Asin", "Darat", "Melahirkan", "Kampung", "1 Tahun")
bubbu.cetak_Kucing()
print("=================================================")
cemong.cetak_Kucing()